package com.bignerdranch.android.disturbnot;
/**
 * Author   : Swati
 * Project  : DisturbNot Application Android
 * File Name: ServiceReceiver
 * Date     : 11/27/2015
 * Description : This class is an activity to create event and on creation of event, it sets pendingIntent
 * to set phone silent mode on when an event starts, this class also starts a broadcast receiver to reset
 * the phone to ringer mode
 *
 * **/

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.CalendarContract;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by Swati on 11/29/2015.
 */
public class AddEventActivity extends Activity {
    //private DatePicker datePicker;
    private Calendar calendar;
    // private TextView dateView;
    private int year, month, day;
    private int hour, minute;
    private Button startDate;
    private Button endDate;
    private Button startTime;
    private Button endTime;
    private Button createEvent;
    private Button cancelEvent;
    private String format = "";
    private long endEventTime = 0;
    private static int minuteStart = 0;
    private static int hourStart = 0;
    private static int minuteFinal = 0;
    private static int hourFinal = 0;
    private static int yearStart, monthStart, dayStart = 0;
    private static int yearFinal, monthFinal, dayFinal = 0;
    public static int id= 0;
    public static boolean isEventOn = false;

    static int DATE_DIALOG_ID = 0;
    static int TIME_DIALOG_ID = 3;

    Timer timer;

    TimerTask timerTask;

    final Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);
        startDate = (Button) findViewById(R.id.startDate);
        endDate = (Button) findViewById(R.id.endDate);
        startTime = (Button) findViewById(R.id.startTime);
        endTime = (Button) findViewById(R.id.endTime);

        createEvent = (Button) findViewById(R.id.createEvent);
        cancelEvent = (Button) findViewById(R.id.cancelEvent);
        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);

        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);

        hour = calendar.get(Calendar.HOUR_OF_DAY);
        minute = calendar.get(Calendar.MINUTE);
        showDate(year, month + 1, day);
        showTime(hour, minute);

        startDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                DATE_DIALOG_ID = 1;
                showDialog(DATE_DIALOG_ID);

            }

        });

        createEvent.setOnClickListener(new View.OnClickListener() {

            @TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
            @Override
            public void onClick(View v) {
                TextView eventName = (TextView) findViewById(R.id.textBoxeventDescription);
                String event = eventName.getText().toString();
                Toast.makeText(AddEventActivity.this,"Event Added to calender", Toast.LENGTH_SHORT).show();

                createCalendarEvent(event);
                Intent addEventActivityIntent = new Intent(AddEventActivity.this, MainActivity.class);
                startActivity(addEventActivityIntent);

            }

        });

        cancelEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addEventActivityIntent = new Intent(AddEventActivity.this, MainActivity.class);
                startActivity(addEventActivityIntent);
            }
        });


        endDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                DATE_DIALOG_ID = 2;
                showDialog(DATE_DIALOG_ID);

            }

        });

        startTime.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                TIME_DIALOG_ID = 4;
                showDialog(TIME_DIALOG_ID);
            }

        });

        endTime.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                TIME_DIALOG_ID = 5;
                showDialog(TIME_DIALOG_ID);
            }

        });
    }



    public void setTime(View view) {

        showTime(hour, minute);
    }


    @SuppressWarnings("deprecation")
    public void setDate(View view) {
        Toast.makeText(getApplicationContext(), "ca", Toast.LENGTH_SHORT)
                .show();
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 1 || id == 2 || id == 0) {
            return new DatePickerDialog(this, myDateListener, year, month, day);
        }
        if (id == 3 || id == 4 || id == 5) {
            return new TimePickerDialog(this, myTimeListener, hour, minute, true);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker arg0, int arg1, int arg2, int arg3) {
            showDate(arg1, arg2+1, arg3);
        }
    };

    private TimePickerDialog.OnTimeSetListener myTimeListener = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            showTime(hourOfDay, minute);
        }

    };

    /**
     *
     * @param year, month, day
     * This function shows date on datepicker button
     */
    private void showDate(int year, int month, int day) {

        if (DATE_DIALOG_ID == 1) {
            dayStart = day;
            monthStart = month;
            yearStart = year;
            startDate.setText(new StringBuilder().append(day).append("/")
                    .append(month).append("/").append(year));

        }
        else if(DATE_DIALOG_ID == 2) {
            dayFinal = day;
            monthFinal = month;
            yearFinal = year;
            endDate.setText(new StringBuilder().append(day).append("/")
                    .append(month).append("/").append(year));

        }else{
            dayFinal = day;
            monthFinal = month;
            yearFinal = year;
            dayStart = day;
            monthStart = month;
            yearStart = year;
            startDate.setText(new StringBuilder().append(day).append("/")
                    .append(month).append("/").append(year));
            endDate.setText(new StringBuilder().append(day).append("/")
                    .append(month).append("/").append(year));
        }
    }

    /**
     *
     * @param hour, min
     * This function sets time on the timepicker
     */
    private void showTime(int hour, int min) {
        int hour24 = hour;
        int minute24 = min;
        if (hour == 0) {
            hour += 12;
            format = "AM";
        }
        else if (hour == 12) {
            format = "PM";
        } else if (hour > 12) {
            hour -= 12;
            format = "PM";
        } else {
            format = "AM";
        }
        System.out.println("TIME_DIALOG_ID -->"+TIME_DIALOG_ID);
        if (TIME_DIALOG_ID == 4) {
            hourStart = hour24;
            minuteStart = minute24;
            startTime.setText(new StringBuilder().append(hour).append(" : ").append(min)
                    .append(" ").append(format));
        }
        else if(TIME_DIALOG_ID == 5) {
            hourFinal = hour24;
            minuteFinal = minute24;
            endTime.setText(new StringBuilder().append(hour).append(" : ").append(min)
                    .append(" ").append(format));
        }else{
            hourFinal = hour24;
            minuteFinal = minute24;
            hourStart = hour24;
            minuteStart = minute24;
            startTime.setText(new StringBuilder().append(hour).append(" : ").append(min)
                    .append(" ").append(format));
            endTime.setText(new StringBuilder().append(hour).append(" : ").append(min)
                    .append(" ").append(format));
        }
    }

    /**
     *
     * @param values
     * This function sets/schedules silent mode and ringer mode setting
     */
    public void onEventCreated(ContentValues values) {
        Calendar calendar = Calendar.getInstance();
        PendingIntent pendingIntent, pendingIntentVibrate;
        Intent myIntent = new Intent(AddEventActivity.this, MyReceiver.class);
        pendingIntent = PendingIntent.getBroadcast(AddEventActivity.this, 0, myIntent, 0);
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        long timeStart = (long) values.get(CalendarContract.Events.DTSTART);
        String duration = (String) values.get(CalendarContract.Events.DURATION);
        long durationSec = 0;

        Duration d = new Duration();
        try {
            d.parse(duration);
            durationSec = d.getMillis();
        } catch (DateException e) {
            e.printStackTrace();
        }
        alarmManager.set(AlarmManager.RTC_WAKEUP, timeStart, pendingIntent);
        long offsetStartTime = timeStart - calendar.getTimeInMillis();

        );
        startTimer(offsetStartTime + durationSec);
    }

    /**
     *
     * @param duration
     * This function sets/schedules ringer mode
     */
    public void startTimer(long duration) {
        timer = new Timer();
        //initialize the TimerTask's job
        initializeTimerTask();
        //schedule the timer, after the duration
        timer.schedule(timerTask, duration, 10000);
    }

    public void initializeTimerTask() {

        timerTask = new TimerTask() {

            public void run() {

                handler.post(new Runnable() {

                    public void run() {

                        //get the current timeStamp

                        Calendar calendar = Calendar.getInstance();

                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd:MMMM:yyyy HH:mm:ss a");

                        final String strDate = simpleDateFormat.format(calendar.getTime());

                       //Send MyReceiverResetRinger broadcast
                        PendingIntent pendingIntentVibrate;
                        Intent myIntentStopVibrate = new Intent(AddEventActivity.this, MyReceiverResetRinger.class);
                        pendingIntentVibrate = PendingIntent.getBroadcast(AddEventActivity.this, 0, myIntentStopVibrate, 0);
                        AlarmManager alarmManager1 = (AlarmManager) getSystemService(ALARM_SERVICE);
                        System.out.print("In timer handler!!!!");
                        if (timer != null) {

                            timer.cancel();

                            timer = null;

                        }

                        alarmManager1.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntentVibrate);

                    }

                });

            }
        };
    }

    /**
     *
     * @param event
     * This function creates calendar event
     */
    public void createCalendarEvent(String event){
        TimeZone tz = TimeZone.getDefault();
        Calendar calendar = GregorianCalendar.getInstance(tz);
        calendar.set(yearStart, monthStart - 1, dayStart,
                hourStart, minuteStart);
        long startTime =
                calendar.getTimeInMillis();

        calendar.set(yearFinal, monthFinal - 1, dayFinal,
                hourFinal, minuteFinal);
        long finalTime = calendar.getTimeInMillis();

        ContentResolver cr = getApplicationContext().getContentResolver();
        ContentValues values = new ContentValues();

        values.put(CalendarContract.Events.DTSTART, startTime);
        values.put(CalendarContract.Events.TITLE, event);
        values.put(CalendarContract.Events.DESCRIPTION, "comment");

        long ss = (((finalTime - startTime) / 1000) % 60);
        long mm = (((finalTime - startTime)/(1000*60)) % 60);
        long hh = (((finalTime - startTime)/(1000*60*60)) % 24);
        System.out.println(" hh "+hh);
        System.out.println(" mm " + mm);
        System.out.println(" ss "+ss);
        TimeZone timeZone = TimeZone.getTimeZone("GMT");
        System.out.println("timeZone.getDisplayName() --->" + timeZone.getDisplayName());
        values.put(CalendarContract.Events.EVENT_TIMEZONE, timeZone.getDisplayName());
        id++;
        // default calendar
        values.put(CalendarContract.Events.CALENDAR_ID, id);

        //for one hour
        //PT1H0M0S
        String dur = "+PT"+hh+"H"+mm+"M"+ss+"S";
        values.put(CalendarContract.Events.DURATION,
                dur);

        values.put(CalendarContract.Events.HAS_ALARM, 1);

        // insert event to calendar
        Uri uri = cr.insert(CalendarContract.Events.CONTENT_URI, values);
        onEventCreated(values);
    }

}
