package com.bignerdranch.android.disturbnot;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ContactList extends AppCompatActivity {
    private TextView mtextViewContacts;
    private TextView mtextViewContactsdescription;
    private Button maddContactsButton;
    private Button mviewContactsButton;
    String contactNumber = null;
    String contactName = null;
    private static final int PICK_CONTACT = 0 ;
    private static final int SEND_CONTACT = 1;
    private Uri uriContact;
    private String contactID;
    public static ArrayList<String> contactList = new ArrayList<String>();//saves the contactName
    public static ArrayList<String> contactNumberList = new ArrayList<String>();//saves the contactNumber
    public int i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);//Removes title from view
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_list);
        maddContactsButton = (Button)findViewById(R.id.add_contacts_button);
        mviewContactsButton = (Button) findViewById(R.id.view_contacts_button);

        //listener to add contact button
        maddContactsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ContactList.this, R.string.add_contacts_toast, Toast.LENGTH_SHORT).show();
                accessContacts();
            }
        });

        //listener for view contact button
        mviewContactsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ContactList.this, R.string.view_contacts_toast, Toast.LENGTH_SHORT).show();

                if ((contactList.isEmpty()) && (contactNumberList.isEmpty())) {
                    Toast.makeText(ContactList.this, "No Emergency Contact List", Toast.LENGTH_SHORT).show();
                } else {
                    Intent viewcontactListIntent = new Intent(ContactList.this, ViewContactListActivity.class);
                    viewcontactListIntent.putExtra("CONTACT_LIST", contactList);
                    startActivity(viewcontactListIntent);//Starting view contact list activity
                }
            }
        });
    }

    //method to access contact ffrom phone contacts
    private void accessContacts(){
        Intent intent= new Intent(Intent.ACTION_PICK,  ContactsContract.Contacts.CONTENT_URI);
        startActivityForResult(intent, PICK_CONTACT);
    }

    //after selecting contacts we get contact info in onActivityResult
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_CONTACT && resultCode == Activity.RESULT_OK) {

            uriContact = data.getData();
            retrieveContactName(); //function to retrieve name from phone contacts
            retrieveContactNumber(); //function to retrieve number from phone contacts
        }

        if (requestCode == SEND_CONTACT && resultCode == Activity.RESULT_OK){
            String string = data.getStringExtra("MyData");
            System.out.println("ok deleted ---> " + string);
            contactList.remove(string);
            int i= contactList.indexOf(string);
            contactNumberList.remove(i);
        }

    }

    private void retrieveContactName(){

        try {

            // querying contact data store
            Cursor cursor = getContentResolver().query(uriContact, null, null, null, null);

            if (cursor.moveToFirst()) {
                // DISPLAY_NAME = The display name for the contact.
                // HAS_PHONE_NUMBER =   An indicator of whether this contact has at least one phone number.
                contactName = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
            }
            cursor.close();
            Log.d("ContactName", "Contact Name: " + contactName);

            // flag to check if the contact already exists in the emergency list
            boolean repeat = false;
            if (contactList.size() == 0) {
                repeat = true; //To add first entry into the list
            }
            for (int i = 0; i < contactList.size(); i++) {
                if (contactName.equals(contactList.get(i))) {
                    //Represents that name is already present in the list.
                    repeat = false;
                    Toast.makeText(ContactList.this, "Contact Already exists in the Emergency List", Toast.LENGTH_SHORT).show();
                    break;
                } else {
                    //name is not there in eList
                    repeat = true;
                }
            }
            //if flag is set then only add the entry to the list
            if (repeat) {
                contactList.add(contactName);
                //repeat = false;
            }

        }catch(Exception e)
        {
            Toast.makeText(ContactList.this, "Invalid Contact Name", Toast.LENGTH_SHORT).show();
            int i = contactList.indexOf(contactName);
            contactList.remove(i);
        }

    }

    private void retrieveContactNumber() {

        try {

        // getting contacts ID
        Cursor cursorID = getContentResolver().query(uriContact,
                new String[]{ContactsContract.Contacts._ID},
                null, null, null);
        if (cursorID.moveToFirst()) {
            contactID = cursorID.getString(cursorID.getColumnIndex(ContactsContract.Contacts._ID));
        }
        cursorID.close();
        Log.d("ContactID", "Contact ID: " + contactID);

        // Using the contact ID now we will get contact phone number
        Cursor cursorPhone = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ? AND " +
                        ContactsContract.CommonDataKinds.Phone.TYPE + " = " +
                        ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE,
                new String[]{contactID},
                null);

        if (cursorPhone.moveToFirst()) {
            //getting the contactNumber based on cursor
            contactNumber = cursorPhone.getString(cursorPhone.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
        }

        cursorPhone.close();
        Log.d("PhoneNumber", "Contact Phone Number: " + contactNumber);
        //Removing special characters from contact Number
        // for example it is stored as  "+1 (503) 803-9470"
        contactNumber=contactNumber.replace("+","");
        contactNumber=contactNumber.replace(" ","");
        contactNumber=contactNumber.replace("(","");
        contactNumber=contactNumber.replace(")","");
        contactNumber=contactNumber.replace("-","");

        boolean repeatNumber = false;
        if (contactNumberList.size()==0) {
            repeatNumber = true;
        }
        for (int i = 0; i < contactNumberList.size(); i++){
            if (contactNumber.equals(contactNumberList.get(i))){
                repeatNumber = false;
                break;
            }
            else {
                repeatNumber = true;
            }
        }
            try{
                if (repeatNumber){
                    contactNumberList.add(contactNumber);
                    repeatNumber = false;
                }
            }catch (Exception e)//:Todo Integration
            {   //to catch the exception of invalid contact - one without number
                Toast.makeText(ContactList.this, "Invalid Contact Number", Toast.LENGTH_SHORT).show();
                int i = contactNumberList.indexOf(contactNumber);
                contactNumberList.remove(i);
                contactList.remove(i);
            }

        }//try ends
        catch (Exception e)//:Todo Integration
        {
            Toast.makeText(ContactList.this, "Invalid Contact Number", Toast.LENGTH_SHORT).show();
            int i = contactNumberList.indexOf(contactNumber);
            contactNumberList.remove(i);
            contactList.remove(i);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_contact_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        // Save UI state changes to the savedInstanceState.
        // This bundle will be passed to onCreate if the process is
        // killed and restarted.
        savedInstanceState.putString("contactNumberString",contactNumber);
        savedInstanceState.putInt("PICK_CONTACT", 0);
        savedInstanceState.putInt("SEND_CONTACT", 1);
        savedInstanceState.putString("contactIDString", contactID);
        savedInstanceState.putStringArrayList("MycontactList", contactList);
        savedInstanceState.putStringArrayList("MyContactNumberList",contactNumberList);
        // etc.
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        // Restore UI state from the savedInstanceState.
        // This bundle has also been passed to onCreate.
        String contactNumber   = savedInstanceState.getString("contactNumberString");
        final int PICK_CONTACT = savedInstanceState.getInt("PICK_CONTACT");
        final int SEND_CONTACT = savedInstanceState.getInt("SEND_CONTACT");
        String contactID = savedInstanceState.getString("contactIDString");
        ArrayList<String> contactList = savedInstanceState.getStringArrayList("MycontactList");
        ArrayList<String> contactNumberList = savedInstanceState.getStringArrayList("MyContactNumberList");
    }
}
