package com.bignerdranch.android.disturbnot;

/**
 * Author   : Swati
 * Project  : DisturbNot Application Android
 * File Name: DateException
 * Date     : 11/28/2015
 * Description : This class creates DateException
 * **/
public class DateException extends Exception
{
    public DateException(String message)
    {
        super(message);
    }
}
