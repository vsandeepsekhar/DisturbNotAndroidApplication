/**
 * Author   : Sandeep
 * Project  : DisturbNot Application Android
 * File Name: MainActivity
 * Date     : 12/06/2015
 * Description : The main activity creates starts an intent to contactlist activity when ever the user selects an add contacts.
 * It also starts an intent to AddEvent activity once the user selects add event.
 * **/
/**
 * Package and Imports
 */
package com.bignerdranch.android.disturbnot;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private TextView mDashBoardTextView;
    private TextView mDescriptionTextView;
    private Button mButtonContactList;
    private Button mButtonAddEvent;
    private Switch mEnableDisableToggleButton;
    @Override
    /**
     * The onCreate method starts an intent for the contactlist activity and addevent activity once
     * the usre selects the buttons.
     */
    protected void onCreate(Bundle savedInstanceState) {
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);//Removes Title from the Screen
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mDashBoardTextView = (TextView)findViewById(R.id.dashboardtextView);
        mDescriptionTextView = (TextView)findViewById(R.id.descriptiontextview);
        mButtonContactList = (Button) findViewById(R.id.button_contact_list);
        mButtonAddEvent = (Button)findViewById(R.id.button_add_event);
        mEnableDisableToggleButton = (Switch) findViewById(R.id.enabledisabletogglebutton);

        mEnableDisableToggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // The toggle is enabled
                    mButtonContactList.setEnabled(false);
                    mButtonAddEvent.setEnabled(false);
                } else {
                    // The toggle is disabled
                    mButtonContactList.setEnabled(true);
                    mButtonAddEvent.setEnabled(true);
                }
            }
        });

        //listener for emergency contact list button
        mButtonContactList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(MainActivity.this, R.string.contact_list_toast, Toast.LENGTH_SHORT).show();
                Intent contactListIntent = new Intent(MainActivity.this, ContactList.class);
                startActivity(contactListIntent);
            }
        });

        //listener for add event button
        mButtonAddEvent.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, R.string.add_event_toast, Toast.LENGTH_SHORT).show();
                Intent AddEventIntent = new Intent(MainActivity.this, AddEventActivity.class);
                startActivity(AddEventIntent);// Starting new 'AddEventActivity' to add event
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        // Save UI state changes to the savedInstanceState.
        // This bundle will be passed to onCreate if the process is
        // killed and restarted.
        savedInstanceState.putBoolean("MyBoolean", true);
        savedInstanceState.putDouble("myDouble", 1.9);
        savedInstanceState.putInt("MyInt", 1);
        savedInstanceState.putString("MyString", "Welcome back to Android");
        // etc.
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        // Restore UI state from the savedInstanceState.
        // This bundle has also been passed to onCreate.
        boolean myBoolean = savedInstanceState.getBoolean("MyBoolean");
        double myDouble = savedInstanceState.getDouble("myDouble");
        int myInt = savedInstanceState.getInt("MyInt");
        String myString = savedInstanceState.getString("MyString");
    }
}
