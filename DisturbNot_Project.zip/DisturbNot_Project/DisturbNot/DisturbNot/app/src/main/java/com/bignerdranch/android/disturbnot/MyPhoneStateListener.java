
package com.bignerdranch.android.disturbnot;

/**
 * Created by Swati on 11/30/2015.
 */
import android.content.Context;
import android.media.AudioManager;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;

public class MyPhoneStateListener extends PhoneStateListener {

    public static Boolean phoneRinging = false;
    public static int silent_caller = 0; //if set indicates incoming number is from emergency list
    public static int SET = 1;
    public static int CLEAR = 0;
    Context context ;
    int prevMode; //Mode which says
    public MyPhoneStateListener(Context context){
        this.context = context;
        AudioManager myAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE); // this is instantitaing the object
        prevMode = myAudioManager.getRingerMode(); //you get ringer mode
    }

    //this method has current phone state and incoming number which
    public void onCallStateChanged(int state, String incomingNumber) {
        AudioManager myAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE); // this is instantitaing the object
        switch (state) {
            case TelephonyManager.CALL_STATE_IDLE: //when call is hung then it goes back to IDLE state.
                Log.d("DEBUG", "IDLE");
                phoneRinging = false;
                silent_caller = CLEAR;
                //setRinger method to set particular mode VIBRATE, SILENT
                myAudioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
                break;
           /* case TelephonyManager.CALL_STATE_OFFHOOK: // during call state is OFFHOOK
                Log.d("DEBUG", "OFFHOOK");
                phoneRinging = false;
                break;*/
            case TelephonyManager.CALL_STATE_RINGING: // when phone rings then state is RINGING
                Log.d("DEBUG", "RINGING");
                phoneRinging = true;
                checkNumber(incomingNumber);
                if(silent_caller == SET){
                    Log.d("DEBUG", "Inside Check Number Function - Changing the Mode ");
                    myAudioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL); //.setRinger method to set particular mode VIBRATE, SILENT
                }
                break;
        }

    }

    //function to check if the incoming number is from emergency list
    public void checkNumber(String incomingNumber){
        Log.d("DEBUG","Inside Check Number Function - SEARCHING Number ");
        ContactList c = new ContactList();  //instantiating the class
        int length = c.contactNumberList.size(); //getting the total length of Emergency list
        System.out.println("num  size--> " + length);
        for(int i = 0 ; i < length; i++ ) { //iterating through complete contact list
            String phone =  c.contactNumberList.get(i);
            Log.d("DEBUG Sub String",phone);
            if(phone.equals(incomingNumber)){ //comparing incoming number with emergency contact list
                silent_caller = SET;
                Log.d("DEBUG", "Inside Check Number Function - SEARCH Successful ");
            }
            else{
                Log.d("DEBUG","NOT EQUAL");
            }

        }
    }

}