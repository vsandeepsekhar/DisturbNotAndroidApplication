package com.bignerdranch.android.disturbnot;
/**
 * Author   : Swati
 * Project  : DisturbNot Application Android
 * File Name: MyReceiver
 * Date     : 11/28/2015
 * Description : This class creates BroadcastReceier which will be called once user's event starts and
 * phone should be set on silent mode
 * **/
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.util.Log;

public class MyReceiver extends BroadcastReceiver
{

	@SuppressLint("NewApi")
	@Override
	public void onReceive(Context context, Intent inten)
	{
		Log.i("App", "called receiver method");
		try{
			AddEventActivity a = new AddEventActivity();
			a.isEventOn = true;
			NotificationManager mManager;
			mManager = (NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);
			Intent intent = new Intent(context,AddEventActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP| Intent.FLAG_ACTIVITY_CLEAR_TOP);
			//Set phone ringer mode to silent
			AudioManager audio = (AudioManager)context.getSystemService(context.AUDIO_SERVICE);
			audio.setRingerMode(0);

			PendingIntent pendingNotificationIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

			//Make notificationn for silent mode on
			Notification.Builder builder = new Notification.Builder(context.getApplicationContext());
			Notification notification = new Notification(R.drawable.ic_launcher,"Time for meeting! Silencing phone", System.currentTimeMillis());
			builder.setAutoCancel(true);
			notification.flags |= Notification.FLAG_AUTO_CANCEL;
			builder.setTicker("Silent mode on");
			builder.setContentTitle("DisturbNot Notification");
			builder.setContentText("Silent mode on");
			builder.setSmallIcon(R.drawable.ic_launcher);
			builder.setContentIntent(pendingNotificationIntent);
			builder.setOngoing(true);
			builder.setNumber(100);
			builder.build();
			notification = builder.getNotification();
			mManager.notify(11, notification);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
