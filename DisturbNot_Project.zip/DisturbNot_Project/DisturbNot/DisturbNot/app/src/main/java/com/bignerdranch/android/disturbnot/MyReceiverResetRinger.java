package com.bignerdranch.android.disturbnot;
/**
 * Author   : Swati
 * Project  : DisturbNot Application Android
 * File Name: MyReceiverResetRinger
 * Date     : 11/28/2015
 * Description : This class creates BroadcastReceier which will be called once user's event ends and
 * phone should be set on ri ger mode
 * **/
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.util.Log;

public class MyReceiverResetRinger extends BroadcastReceiver
{

	@SuppressLint("NewApi")
	@Override
	public void onReceive(Context context, Intent inten)
	{

		Log.i("App", "called receiver method");
		try{
			Log.i("App", "called RESET receiver method");
			AddEventActivity a = new AddEventActivity();
			a.isEventOn = false;
			NotificationManager mManager;
			mManager = (NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);
			Intent intent = new Intent(context,AddEventActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP| Intent.FLAG_ACTIVITY_CLEAR_TOP);
			//Set Phone ringer mode to ringer mode
			AudioManager audio = (AudioManager)context.getSystemService(context.AUDIO_SERVICE);
			audio.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
			PendingIntent pendingNotificationIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
			//Create a notification for Ringer mode on
			Notification.Builder builder = new Notification.Builder(context.getApplicationContext());
			Notification notification = new Notification(R.drawable.ic_launcher,"Time for meeting! Silencing phone", System.currentTimeMillis());
			builder.setAutoCancel(true);
			notification.flags |= Notification.FLAG_AUTO_CANCEL;
			builder.setTicker("Ringer mode on");
			builder.setContentTitle("DisturbNot Notification");
			builder.setContentText("Ringer mode on");
			builder.setSmallIcon(R.drawable.ic_launcher);
			builder.setContentIntent(pendingNotificationIntent);
			builder.setOngoing(true);
			builder.setNumber(100);
			builder.build();
			notification = builder.getNotification();
			mManager.notify(11, notification);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
