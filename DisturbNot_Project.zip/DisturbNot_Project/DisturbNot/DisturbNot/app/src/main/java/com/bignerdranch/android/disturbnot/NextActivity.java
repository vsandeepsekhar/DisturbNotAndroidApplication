package com.bignerdranch.android.disturbnot;
/**
 * Author   : Swati
 * Project  : DisturbNot Application Android
 * File Name: NextActivity
 * Date     : 12/01/2015
 * Description : This class is an activity it starts after user clicks on ntification, curretly it
 * does nothing but sets main view
 * **/
import android.app.Activity;
import android.os.Bundle;

public class NextActivity extends Activity
{

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}	
}
