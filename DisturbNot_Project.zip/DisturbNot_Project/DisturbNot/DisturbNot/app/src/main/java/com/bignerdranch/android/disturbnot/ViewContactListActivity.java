/**
 * Author   : Sandeep
 * Project  : DisturbNot Application Android
 * File Name: ViewConatctListActivity
 * Date     : 12/06/2015
 * Description : The View Contact List Activity views the contacts in a list view. The OnCreate method gets an intent
 * from the ContactList activity as the contacts to be displayed.Once the intent is got from the contactlist it is added
 * to the arraylist myList. then the adapter is created using the arralistadapter class and the adapter populates the
 * contact list. whenever the user selects the contact to to be deleted the adapter deletes that from the view and the
 * contactname from the contactlist and contactnumber from the contactlistnumber is deleted.
 * **/
/**
 * Package and Imports
 */
package com.bignerdranch.android.disturbnot;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 *The ViewContactListActivity is the activity class deals with the ListView and delete contact
 */
public class ViewContactListActivity extends AppCompatActivity {

    ListView listView ;
    private CheckBox mitemCheckBox;
    private Button mcontactDeleteButton;
    private static char flag;
    private ArrayList<String> myList;

    /**
     *
     * @param savedInstanceState
     * The Oncreate method deals with creating the ListView and deleting the contact using the
     * Arrayadapter class and views the contacts using the adapter.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);//This makes the title to be not shown on the screen
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view_android_example);//populates the activity_list_view_android_example
        myList = (ArrayList<String>) getIntent().getStringArrayListExtra("CONTACT_LIST");//gets the intent from the contactList class
        listView = (ListView) findViewById(R.id.list);// Get ListView object from xml

        // Define a new Adapter
        // First parameter - Context
        // Second parameter - Layout for the row
        // Third parameter - ID of the TextView to which the data is written
        // Forth - the Array of data

        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, myList);


        // Assign adapter to ListView
        listView.setAdapter(adapter);

        // ListView Item Click Listener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {//gets invoked whenever the user clicks one of the contact from the listView

                // ListView Clicked item index
                int itemPosition     = position;

                // ListView Clicked item value
                String  itemValue    = (String) listView.getItemAtPosition(position);
                adapter.remove(itemValue);//remove this item from the list view
                ContactList contactList = new ContactList();//create a new object of the contactlist
                int i = contactList.contactList.indexOf(itemValue);//find the index of the item in contactlist arraylist
                contactList.contactList.remove(i);//remove the item from the arraylist
                contactList.contactNumberList.remove(i);//remove the number from the contact list

                // Show Alert
                Toast.makeText(getApplicationContext(),
                         itemValue + " deleted", Toast.LENGTH_LONG)
                        .show();
            }

        });
    }
}
